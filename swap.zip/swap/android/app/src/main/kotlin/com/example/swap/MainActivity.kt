package com.example.swap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

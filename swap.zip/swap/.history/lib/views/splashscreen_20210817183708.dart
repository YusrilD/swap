import 'package:flutter/material.dart';
import 'package:swap/views/source/assets_app.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Image.asset(
              AssetsApp.splashscreenImg,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }
}

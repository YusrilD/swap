class AppColors{

  static int primaryColorMainApp = 0xFF171D2D;

}
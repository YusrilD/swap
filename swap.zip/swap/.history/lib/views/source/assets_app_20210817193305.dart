class AssetsApp{
  static String splashscreenImg = "assets/splashscreen_img.jpg";
  static String googleLogoImg = "assets/google_logo_img.png";

}
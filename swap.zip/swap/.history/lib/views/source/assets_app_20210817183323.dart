class AssetsApp{
  static String splashscreenImg = "assets/splashscreen_img.jpg";
}
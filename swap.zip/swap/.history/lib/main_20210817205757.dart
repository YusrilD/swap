import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:swap/services/service.dart';
import 'package:swap/views/app.dart';

void main() {
  runApp(App());
}

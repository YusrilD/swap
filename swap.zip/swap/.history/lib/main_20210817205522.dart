import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:swap/services/service.dart';
import 'package:swap/views/app.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamProvider.value(
      value: Services.firebaseUserStream,
      child: MaterialApp(
        home: App(),
      ),
    );
  }
}

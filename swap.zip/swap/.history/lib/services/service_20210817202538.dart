import 'package:firebase_auth/firebase_auth.dart';

class Services {
  static FirebaseAuth _auth = FirebaseAuth.instance;

  static Future signInEmail() async {
    UserCredential result = await _auth.signInWithEmailAndPassword(email: null, password: null);
  }
}

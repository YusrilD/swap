import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class Services {
  static FirebaseAuth _auth = FirebaseAuth.instance;

  static Future<User> signInEmail() async {
    try {

      UserCredential result =
          await _auth.signInWithEmailAndPassword(email: null, password: null);
      User firebaseUser = result.user;

      return firebaseUser;
    } catch (e) {
      print(e);
      return null;
    }
  }

  Future<void> signInWithGoogle() async {
    print("Sign in function called");
    final googleSignIn = GoogleSignIn();
    final googleUser = await googleSignIn.signIn();
    print("Test google user $googleUser");
    if (googleUser != null) {
      final googleAuth = await googleUser.authentication;
      if (googleAuth.idToken != null) {
        final userCredential = await _auth.signInWithCredential(
          GoogleAuthProvider.credential(
              idToken: googleAuth.idToken, accessToken: googleAuth.accessToken),
        );
        return userCredential.user;
      }
    } else {
      throw FirebaseAuthException(
        message: "Sign in aborded by user",
        code: "ERROR_ABORDER_BY_USER",
      );
    }
  }

  static Future<void> signOut() async{
      _auth.signOut();
  }

  static Stream<User> get firebaseUserStream => _auth.authStateChanges();
}

import 'package:firebase_auth/firebase_auth.dart';

class Services {
  static FirebaseAuth _auth = FirebaseAuth.instance;

  static Future<User> signInEmail() async {
    try {

      UserCredential result =
          await _auth.signInWithEmailAndPassword(email: null, password: null);
      User firebaseUser = result.user;

      return firebaseUser;
    } catch (e) {
      print(e);
      return null;
    }
  }

  static Future<void> signOut() async{
      _auth.signOut();
  }

  static Stream<User> get firebaseUserStream => _auth.authStateChanges();
}

import 'package:flutter/material.dart';
import 'package:swap/views/app.dart';

void main() {
  runApp(App());
}